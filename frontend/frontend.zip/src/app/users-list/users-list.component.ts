import {Component, OnInit} from '@angular/core';
import {AuthenticationService} from '../authentication.service';
import {Router} from '@angular/router';
import {UsersManagementService} from '../users-management.service';

const AWS = require('aws-sdk');

@Component({
  selector: 'app-users-list',
  templateUrl: './users-list.component.html',
  styleUrls: ['./users-list.component.css']
})
export class UsersListComponent implements OnInit {
  usersListCognito = [];
  cognitoidentityserviceprovider;

  constructor(private auth: AuthenticationService,
              private _router: Router, private userService: UsersManagementService) {
  }

  testKlik() {
    this.auth.signIn('lord360@wp.pl', 'Qwerty123!').subscribe((data) => {
      console.log('zalogowano');
    }, (err) => {
      console.log(err);
    });
  }

  testKlik2() {
    if (this.auth.isLoggedIn()) {
      this.auth.logOut();
      console.log('wylogowano');
    }
    this._router.navigateByUrl('/login');
  }

  testKlik3() {
    // this.deleteUser('e40acf3a-83ef-4385-9897-4a5223d6e374');
  }

  updateAttributes(Username) {
    const params = {
      UserAttributes: [
        {
          Name: 'custom:recruiter',
          Value: '0'
        },
        {
          Name: 'given_name',
          Value: 'Fajny'
        },
        {
          Name: 'family_name',
          Value: 'Admin'
        },
        {
          Name: 'custom:role',
          Value: '0'
        }
      ],
      UserPoolId: 'us-east-1_IBVZb8BoB', /* required */
      Username: Username, /* required */
    };
    this.cognitoidentityserviceprovider.adminUpdateUserAttributes(params, (err, data) => {
      if (err) {
        console.log(err, err.stack);
      } else {
        console.log(data);
      }           // successful response
    });
  }

  ngOnInit(): void {
    if (this.auth.isLoggedIn()) {
      this.userService.getUsers(this.auth.getAuthenticatedUser().getUsername()).subscribe( (data) => {
          this.usersListCognito = data;
        }
      );
    }
  }
}
